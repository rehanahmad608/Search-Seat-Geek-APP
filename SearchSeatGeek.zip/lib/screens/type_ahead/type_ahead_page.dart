import 'package:flutter/material.dart';

import 'type_ahead_screen.dart';

class TypeAheadPage extends MaterialPage {
  const TypeAheadPage()
      : super(
          child: const TypeAheadPageScreen(),
        );
}
