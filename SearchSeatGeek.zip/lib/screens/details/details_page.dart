import 'package:flutter/material.dart';

import 'details_screen.dart';

class DetailPage extends MaterialPage {
  const DetailPage()
      : super(
          child: const DetailsScreen(),
        );
}
