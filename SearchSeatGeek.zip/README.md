# Flutterapp

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.


How to run the app:

Using VSCode: Open or clone the github repository in your folder.
Open in VSCode, start the emulator and run the app.

On search page, type the query in the textfield and wait for results to update.

Results are shown in a list view and each result can be tap to view in details page.

Use cancel button to clear the search field.


For Android apk: run flutter build apk in terminal.
