package com.example.type_ahead

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
